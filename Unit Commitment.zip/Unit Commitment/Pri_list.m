function [p,cost]=Pri_list(h,C,plower,pupper,pd)
% h=[510 72 0.00142;310 7.85 0.00194;78 7.97 0.00482];
% C=[1.1 1.0 1.2];
% plower=[150 100 50];
% pupper=[600 400 200];
% pd=550;
n=length(plower);
disp('F(p)=')
for i=1:n
cost(i,:)=h(i,:)*C(1,i);
disp(cost(i,:));
end
for i=1:n
a(i,1)=cost(i,1);
b(i,1)=cost(i,2);
y(i,1)=cost(i,3);
end
disp('full load average cost=')
for i=1:n
fla(i,1)=(a(i,1)+b(i,1)*pupper(1,i)+y(i,1)*pupper(1,i)^2)/pupper(1,i);
disp(fla(i,1))
end
p=fla;
p(:,2)=plower';
p(:,3)=pupper';
p=sortrows(p);
p(1,4)=p(1,2);
p(1,5)=p(1,3);
for i=1:n-1
p(i+1,4)=p(i+1,2)+p(i,4);
p(i+1,5)=p(i+1,3)+p(i,5);
end
for i=1:n
if pd>=p(i,5)
p(i,6)=p(i,3);
end
if pd<p(i,5)
g=0;
for j=1:i-1
g=g+p(j,3);
end
p(i,6)=pd-g;
end
end
for i=1:n
if p(i,6)<0
p(i,6)=0;
end
end
c=p(:,6);
cost=sum( [sum(a) sum(b.*c) sum(y.*c.*c)]);
end